package exchange.domain;

import java.math.BigDecimal;

/** Nilai uang = jumlah (BigDecimal, bukan double) + mata uang. Tidak bisa diubah (immutable). */
public final class Money {
    private final BigDecimal amount;
    private final Currency currency;

    public Money(BigDecimal amount, Currency currency) {
        this.amount = amount;
        this.currency = currency;
    }

    public Money(String amount, Currency currency) {
        this(new BigDecimal(amount), currency);
    }

    public BigDecimal amount()   { return amount; }
    public Currency currency()   { return currency; }

    @Override
    public String toString() {
        return currency.format(amount);
    }
}
