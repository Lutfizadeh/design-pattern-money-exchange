package exchange.domain;

import java.math.BigDecimal;

/** Nasabah MEMBELI mata uang asing: spread 1,5%, tanpa biaya tambahan. */
public class BuyTransaction extends ExchangeTransaction {

    public BuyTransaction(RateTable rates) {
        super(rates);
    }

    @Override
    protected String typeName() {
        return "beli";
    }

    @Override
    protected BigDecimal spreadPercent() {
        return new BigDecimal("1.5");
    }
    // feePercent() tidak di-override: memakai hook default (0).
}
