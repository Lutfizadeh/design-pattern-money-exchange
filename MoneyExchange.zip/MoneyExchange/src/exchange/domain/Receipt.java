package exchange.domain;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** Struk hasil transaksi. Hanya menyimpan data; tidak ada logika bisnis. */
public final class Receipt {
    private final String type;
    private final Money source;
    private final Money received;
    private final BigDecimal midRate;
    private final BigDecimal customerRate;
    private final Money fee;
    private final LocalDateTime time;

    public Receipt(String type, Money source, Money received,
                   BigDecimal midRate, BigDecimal customerRate, Money fee) {
        this.type = type;
        this.source = source;
        this.received = received;
        this.midRate = midRate;
        this.customerRate = customerRate;
        this.fee = fee;
        this.time = LocalDateTime.now();
    }

    public String type()          { return type; }
    public Money source()         { return source; }
    public Money received()       { return received; }
    public BigDecimal midRate()   { return midRate; }
    public BigDecimal customerRate() { return customerRate; }
    public Money fee()            { return fee; }
    public LocalDateTime time()   { return time; }

    @Override
    public String toString() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        StringBuilder sb = new StringBuilder();
        sb.append("========== STRUK ").append(type.toUpperCase()).append(" ==========\n");
        sb.append("Waktu          : ").append(time.format(fmt)).append('\n');
        sb.append("Anda serahkan  : ").append(source).append('\n');
        sb.append("Kurs tengah    : 1 ").append(source.currency()).append(" = ")
          .append(String.format(Locale.US, "%.6f", midRate)).append(' ')
          .append(received.currency()).append('\n');
        sb.append("Kurs Anda      : 1 ").append(source.currency()).append(" = ")
          .append(String.format(Locale.US, "%.6f", customerRate)).append(' ')
          .append(received.currency()).append('\n');
        sb.append("Biaya          : ").append(fee).append('\n');
        sb.append("Anda terima    : ").append(received).append('\n');
        sb.append("=================================\n");
        return sb.toString();
    }
}
