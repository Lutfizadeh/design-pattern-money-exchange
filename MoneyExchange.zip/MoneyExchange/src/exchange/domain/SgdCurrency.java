package exchange.domain;

/** Dolar Singapura: 2 desimal (sen). */
public class SgdCurrency extends Currency {
    @Override public String code()     { return "SGD"; }
    @Override public String name()     { return "Dolar Singapura"; }
    @Override public String symbol()   { return "S$"; }
    @Override public int decimals()    { return 2; }
}
