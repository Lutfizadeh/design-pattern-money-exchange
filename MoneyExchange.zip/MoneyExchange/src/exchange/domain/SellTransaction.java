package exchange.domain;

import java.math.BigDecimal;

/** Nasabah MENJUAL mata uang asing: spread 1%, ditambah biaya layanan 0,5%. */
public class SellTransaction extends ExchangeTransaction {

    public SellTransaction(RateTable rates) {
        super(rates);
    }

    @Override
    protected String typeName() {
        return "jual";
    }

    @Override
    protected BigDecimal spreadPercent() {
        return new BigDecimal("1.0");
    }

    @Override
    protected BigDecimal feePercent() {   // override hook
        return new BigDecimal("0.5");
    }
}
