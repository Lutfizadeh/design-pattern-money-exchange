package exchange.domain;

/** FACTORY kedua: memilih jenis transaksi ("beli" / "jual"). */
public final class TransactionFactory {

    private TransactionFactory() { }

    public static ExchangeTransaction create(String type, RateTable rates) {
        if (type == null) {
            throw new IllegalArgumentException("Jenis transaksi tidak boleh kosong.");
        }
        switch (type.trim().toLowerCase()) {
            case "beli":
                return new BuyTransaction(rates);
            case "jual":
                return new SellTransaction(rates);
            default:
                throw new IllegalArgumentException("Jenis transaksi tidak dikenal: " + type);
        }
    }
}
