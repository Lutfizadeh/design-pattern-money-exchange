package exchange.domain;

/** Dilempar saat kode mata uang tidak dikenal oleh factory atau tabel kurs. */
public class UnsupportedCurrencyException extends RuntimeException {
    public UnsupportedCurrencyException(String code) {
        super("Mata uang tidak didukung: " + code);
    }
}
