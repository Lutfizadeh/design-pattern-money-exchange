package exchange.domain;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Locale;

/**
 * Produk (product) dalam pola Factory Method.
 * Setiap mata uang punya aturan sendiri: jumlah desimal, jumlah minimum, simbol.
 * Kode lain cukup bergantung pada class abstrak ini, tidak perlu tahu IdrCurrency, SgdCurrency, dst.
 */
public abstract class Currency {

    public abstract String code();      // contoh: "IDR"
    public abstract String name();      // contoh: "Rupiah Indonesia"
    public abstract String symbol();    // contoh: "Rp"
    public abstract int decimals();     // jumlah angka di belakang koma

    /** Hook: jumlah minimum yang boleh ditukar. Subclass boleh mengubahnya. */
    public BigDecimal minimumAmount() {
        return BigDecimal.ONE;
    }

    /** Membulatkan sesuai aturan desimal mata uang ini. */
    public BigDecimal round(BigDecimal value) {
        return value.setScale(decimals(), RoundingMode.HALF_UP);
    }

    /** Format tampilan, contoh: "Rp 1,000,000" atau "S$ 85.30". */
    public String format(BigDecimal value) {
        return symbol() + " " + String.format(Locale.US, "%,." + decimals() + "f", round(value));
    }

    @Override
    public boolean equals(Object other) {
        return other instanceof Currency && ((Currency) other).code().equals(code());
    }

    @Override
    public int hashCode() {
        return code().hashCode();
    }

    @Override
    public String toString() {
        return code();
    }
}
