package exchange.domain;

/** Dilempar saat jumlah uang tidak valid (nol, negatif, atau di bawah minimum). */
public class InvalidAmountException extends RuntimeException {
    public InvalidAmountException(String message) {
        super(message);
    }
}
