package exchange.domain;

import java.math.BigDecimal;

/** Rupiah: tanpa desimal, minimum penukaran Rp 10.000. */
public class IdrCurrency extends Currency {
    @Override public String code()     { return "IDR"; }
    @Override public String name()     { return "Rupiah Indonesia"; }
    @Override public String symbol()   { return "Rp"; }
    @Override public int decimals()    { return 0; }

    @Override
    public BigDecimal minimumAmount() {
        return new BigDecimal("10000");
    }
}
