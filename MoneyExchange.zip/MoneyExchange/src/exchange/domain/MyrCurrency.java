package exchange.domain;

/** Ringgit Malaysia: 2 desimal (sen). */
public class MyrCurrency extends Currency {
    @Override public String code()     { return "MYR"; }
    @Override public String name()     { return "Ringgit Malaysia"; }
    @Override public String symbol()   { return "RM"; }
    @Override public int decimals()    { return 2; }
}
