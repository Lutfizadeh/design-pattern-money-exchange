package exchange.domain;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.HashMap;
import java.util.Map;

/**
 * Tabel kurs FIKTIF untuk latihan (bukan kurs asli).
 * Semua kurs disimpan terhadap satu mata uang dasar (USD): "berapa unit mata uang X per 1 USD".
 * Konversi silang (misal THB -> IDR) dihitung lewat USD, jadi tabelnya hanya N entri, bukan N x N.
 */
public class RateTable {

    private final Map<String, BigDecimal> perUsd = new HashMap<String, BigDecimal>();

    public RateTable() {
        perUsd.put("IDR", new BigDecimal("16000"));
        perUsd.put("MYR", new BigDecimal("4.50"));
        perUsd.put("SGD", new BigDecimal("1.35"));
        perUsd.put("THB", new BigDecimal("35.00"));
        perUsd.put("VND", new BigDecimal("25000"));
    }

    /** Kurs tengah (mid rate): 1 unit 'from' = berapa unit 'to'. */
    public BigDecimal midRate(Currency from, Currency to) {
        BigDecimal fromPerUsd = lookup(from);
        BigDecimal toPerUsd = lookup(to);
        return toPerUsd.divide(fromPerUsd, MathContext.DECIMAL64);
    }

    private BigDecimal lookup(Currency currency) {
        BigDecimal rate = perUsd.get(currency.code());
        if (rate == null) {
            throw new UnsupportedCurrencyException(currency.code());
        }
        return rate;
    }
}
