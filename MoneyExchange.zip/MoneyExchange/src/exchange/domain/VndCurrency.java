package exchange.domain;

import java.math.BigDecimal;

/** Dong Vietnam: tanpa desimal, minimum penukaran 50.000 dong. */
public class VndCurrency extends Currency {
    @Override public String code()     { return "VND"; }
    @Override public String name()     { return "Dong Vietnam"; }
    @Override public String symbol()   { return "VND"; }
    @Override public int decimals()    { return 0; }

    @Override
    public BigDecimal minimumAmount() {
        return new BigDecimal("50000");
    }
}
