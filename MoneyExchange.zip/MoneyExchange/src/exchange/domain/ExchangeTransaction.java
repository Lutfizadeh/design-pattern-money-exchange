package exchange.domain;

import java.math.BigDecimal;

/**
 * TEMPLATE METHOD.
 *
 * execute() adalah "kerangka algoritma": urutan langkahnya TETAP dan tidak bisa diubah
 * subclass karena ditandai 'final'. Subclass hanya mengisi langkah yang berbeda:
 *
 *   - typeName()      : wajib diisi (abstract)
 *   - spreadPercent() : wajib diisi (abstract)
 *   - feePercent()    : opsional / HOOK (default 0, boleh di-override)
 *   - validate()      : opsional / HOOK (default sudah ada, boleh ditambah)
 */
public abstract class ExchangeTransaction {

    private static final BigDecimal HUNDRED = new BigDecimal("100");

    private final RateTable rates;

    protected ExchangeTransaction(RateTable rates) {
        this.rates = rates;
    }

    // ===================== TEMPLATE METHOD =====================
    public final Receipt execute(Money source, Currency target) {
        validate(source, target);                                    // 1. validasi

        BigDecimal midRate = rates.midRate(source.currency(), target);   // 2. kurs tengah
        BigDecimal customerRate = adjustRate(midRate);               // 3. terapkan spread
        BigDecimal gross = source.amount().multiply(customerRate);   // 4. hitung kotor
        BigDecimal fee = calculateFee(gross);                        // 5. hitung biaya
        BigDecimal net = target.round(gross.subtract(fee));          // 6. bulatkan sesuai mata uang

        return new Receipt(typeName(), source, new Money(net, target),
                midRate, customerRate, new Money(fee, target));      // 7. buat struk
    }
    // ===========================================================

    // ---- Langkah yang WAJIB diisi subclass ----
    protected abstract String typeName();

    /** Selisih kurs yang diambil penyedia jasa, dalam persen (misal 1.5 = 1,5%). */
    protected abstract BigDecimal spreadPercent();

    // ---- Hook: langkah opsional ----
    protected BigDecimal feePercent() {
        return BigDecimal.ZERO;
    }

    protected void validate(Money source, Currency target) {
        if (source.amount().signum() <= 0) {
            throw new InvalidAmountException("Jumlah harus lebih besar dari nol.");
        }
        if (source.currency().equals(target)) {
            throw new InvalidAmountException("Mata uang asal dan tujuan tidak boleh sama.");
        }
        BigDecimal minimum = source.currency().minimumAmount();
        if (source.amount().compareTo(minimum) < 0) {
            throw new InvalidAmountException("Jumlah minimum penukaran "
                    + source.currency().format(minimum) + ".");
        }
    }

    // ---- Langkah konkret yang dipakai bersama ----
    private BigDecimal adjustRate(BigDecimal midRate) {
        BigDecimal factor = BigDecimal.ONE.subtract(spreadPercent().divide(HUNDRED));
        return midRate.multiply(factor);
    }

    private BigDecimal calculateFee(BigDecimal gross) {
        return gross.multiply(feePercent()).divide(HUNDRED);
    }
}
