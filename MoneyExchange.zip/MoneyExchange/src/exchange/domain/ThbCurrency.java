package exchange.domain;

import java.math.BigDecimal;

/** Baht Thailand: 2 desimal (satang), minimum penukaran 100 baht. */
public class ThbCurrency extends Currency {
    @Override public String code()     { return "THB"; }
    @Override public String name()     { return "Baht Thailand"; }
    @Override public String symbol()   { return "THB"; }
    @Override public int decimals()    { return 2; }

    @Override
    public BigDecimal minimumAmount() {
        return new BigDecimal("100");
    }
}
