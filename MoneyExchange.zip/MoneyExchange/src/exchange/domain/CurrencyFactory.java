package exchange.domain;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * FACTORY: satu-satunya tempat yang tahu class konkret mana yang dibuat.
 * Kode lain (termasuk UI nanti) cukup memanggil CurrencyFactory.create("SGD").
 *
 * Menambah mata uang baru = membuat class baru + satu baris di static block.
 * Tidak ada if/else di tempat lain.
 */
public final class CurrencyFactory {

    private static final Map<String, Currency> REGISTRY = new LinkedHashMap<String, Currency>();

    static {
        register(new IdrCurrency());
        register(new MyrCurrency());
        register(new SgdCurrency());
        register(new ThbCurrency());
        register(new VndCurrency());
    }

    private CurrencyFactory() { }

    private static void register(Currency currency) {
        REGISTRY.put(currency.code(), currency);
    }

    public static Currency create(String code) {
        if (code == null) {
            throw new UnsupportedCurrencyException("null");
        }
        Currency currency = REGISTRY.get(code.trim().toUpperCase());
        if (currency == null) {
            throw new UnsupportedCurrencyException(code);
        }
        return currency;
    }

    /** Daftar mata uang yang didukung (berguna untuk mengisi dropdown di UI). */
    public static List<Currency> supported() {
        return new ArrayList<Currency>(REGISTRY.values());
    }
}
