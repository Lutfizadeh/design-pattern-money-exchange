package exchange;

import exchange.domain.Currency;
import exchange.domain.CurrencyFactory;
import exchange.domain.ExchangeTransaction;
import exchange.domain.Money;
import exchange.domain.RateTable;
import exchange.domain.Receipt;
import exchange.domain.TransactionFactory;

/** Uji domain lewat konsol (tanpa UI). Semua kurs di RateTable adalah data fiktif. */
public class Main {

    public static void main(String[] args) {
        RateTable rates = new RateTable();

        System.out.println("Mata uang yang didukung:");
        for (Currency c : CurrencyFactory.supported()) {
            System.out.println("  " + c.code() + " - " + c.name());
        }
        System.out.println();

        // 1. Beli SGD dengan 1.000.000 IDR
        run("jual", "10000", "IDR", "SGD", rates);

        // 2. Jual THB 5.000 untuk dapat MYR (ada biaya layanan)
        run("jual", "5000", "THB", "MYR", rates);

        // 3. Tujuan tanpa desimal: SGD -> VND
        run("beli", "100", "SGD", "VND", rates);

        // 4. Kasus error
        run("beli", "5000", "IDR", "SGD", rates);     // di bawah minimum IDR
        run("beli", "-10", "SGD", "MYR", rates);      // jumlah negatif
        run("beli", "100", "SGD", "SGD", rates);      // mata uang sama
        run("beli", "100", "SGD", "XYZ", rates);      // mata uang tidak dikenal
        run("tukar", "100", "SGD", "MYR", rates);     // jenis transaksi tidak dikenal
    }

    private static void run(String type, String amount, String from, String to, RateTable rates) {
        System.out.println(">>> " + type + " " + amount + " " + from + " -> " + to);
        try {
            Currency source = CurrencyFactory.create(from);
            Currency target = CurrencyFactory.create(to);
            ExchangeTransaction transaction = TransactionFactory.create(type, rates);
            Receipt receipt = transaction.execute(new Money(amount, source), target);
            System.out.println(receipt);
        } catch (RuntimeException e) {
            System.out.println("GAGAL: " + e.getMessage() + "\n");
        }
    }
}
